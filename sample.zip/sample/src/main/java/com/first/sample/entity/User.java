package com.first.sample.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Entity
@Data
public class User {
	@Id
	private int id;
	private String name;
	private String place;
	
}
