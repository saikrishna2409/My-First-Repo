package com.first.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.first.sample.entity.User;
import com.first.sample.repo.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo ur;
public List<User> getUsers() {
	return ur.findAll();
	
}
public String saveUSER(User user) {
	ur.save(user);
	return "Success";
}
public User getById(int id) {
	
	return ur.findById(id).orElse(null);
}
}
