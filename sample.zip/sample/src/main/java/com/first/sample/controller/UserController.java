package com.first.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.first.sample.entity.User;
import com.first.sample.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {

	@Autowired
	UserService us;
	@RequestMapping(method = RequestMethod.GET,value ="/users")
	public List<User> getUsers() {
		return us.getUsers();
	}
	
	@RequestMapping(method = RequestMethod.POST,value ="/add")
	public String saveUser(@RequestBody  User user) {
		return us.saveUSER(user);
	}
	
	@GetMapping("/{id}")
	public User getById(@PathVariable int id) {
		return us.getById(id);
	}
}
